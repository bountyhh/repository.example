import xbmcaddon

MainBase = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3LzdTclRMVmFx'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.exl')